package vcs;

import java.util.Iterator;

import objects.AbstractVCSTree;
import objects.VCSBlob;
import objects.VCSCommit;
import objects.VCSTree;

public class VCS {

	public static void main(String[] args){
		Operations ops = new Operations();
		//ops.initRepository("./");

//		ops.commit(stagedFiles, null,"initial commit", "", "", "./");
		
//		VCSBlob blob1 = new VCSBlob("hello.c", "./root/hello.c", "./");
//		//blob1.writeObjectToDisk();
//		
//		VCSBlob blob2 = new VCSBlob("new.c", "./root/new/new.c", "./");
////		blob2.writeObjectToDisk();
//		
//		VCSTree tree1 = new VCSTree("new", "./root/new/", "./");
//		tree1.addItem(blob2);
//		System.out.println(tree1.generateTreeHash());
////		tree1.writeObjectToDisk();
////		
//		VCSTree tree2 = new VCSTree("root", "./root/", "./");
//		tree2.addItem(tree1);
//		tree2.addItem(blob1);
//		System.out.println(tree2.generateTreeHash());
//		//tree2.writeTreeToDisk();
//		System.out.print(tree2.printTree(0));
//		
//		VCSCommit commit = new VCSCommit("./", null, tree2, "new commit", "aher", "aher");
//		System.out.println("commit hash		"+commit.getObjectHash());
//		commit.writeCommitToDisk();
//		
		
		//VCSBlob blob = new VCSBlob("7dc736115fddc4a178c7f38061d739d8ad36bbceccea597cdb3a9f17557c", "./", "./tree", "tree");
		//System.out.println(blob.writeOriginalToDisk());
//	
		//VCSTree tree = new VCSTree("7dc736115fddc4a178c7f38061d739d8ad36bbceccea597cdb3a9f17557c", "./", "./root", "root");
		//tree.writeOriginalToDisk();
		//System.out.print(tree.printTree(0));
		//VCSCommit commit = new VCSCommit("./", null, tree2, "ini Commit", "prashant", "prashnayt");
//		commit.writeObjectToDisk();
//		System.out.println(commit.getObjectHash());
		
		VCSCommit co = new VCSCommit("976c7552fc5a7396fc4bbe97ef794353852240dd19511ccf7a4f5520c674fe", "./",true);
//		//System.out.println("commit msg:"+co.getCommitMessage());
//		//co.getTree().writeOriginalToDisk();
//		

		//String[] stagedFiles = {"root/new1/3.c","root/new1/new4/5.c","root/new2/1.c","root/new2/2.c"};
		String[] stagedFiles = {"root/new1/new4/5.c","root/new2/2.c"};
		
//		VCSCommit co = new VCSCommit("f920c3962e985115e97567a16620133e48848823b0672737f957716edb57cbd5", "./",true);
		Iterator<AbstractVCSTree> it = co.getTree().getImmediateChildren().listIterator();
		while(it.hasNext()){
			(it.next()).writeOriginalToDisk();
		}
//	ops.commit(stagedFiles, co,"initial commit", "aher", "aher", "./");
	
	}
	
}
