hello i am in root
folder
